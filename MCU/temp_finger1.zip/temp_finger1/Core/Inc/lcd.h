#ifndef LCD_I2C_H
#define LCD_I2C_H

#include "main.h"
#include "stdio.h"

#define LCD_ADDRESS 0x27 // I2C address of the LCD

void LCD_I2C_Init();
void LCD_I2C_SendCommand(uint8_t command);
void LCD_I2C_SendData(uint8_t data);
void LCD_I2C_Clear();
void LCD_I2C_SetCursor(uint8_t row, uint8_t col);
void LCD_I2C_WriteString(char *str);

#endif /* LCD_I2C_H */
