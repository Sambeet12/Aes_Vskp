#include "lcd.h"

extern I2C_HandleTypeDef hi2c2;

void LCD_I2C_Init() {
    // Initialization sequence for 4-bit mode
    HAL_Delay(50);  // Wait for LCD to power up
    LCD_I2C_SendCommand(0x33); // Initialize
    HAL_Delay(5);
    LCD_I2C_SendCommand(0x32); // Enable 4-bit mode
    HAL_Delay(1);
    LCD_I2C_SendCommand(0x28); // 2 Lines, 5x8 Matrix
    HAL_Delay(1);
    LCD_I2C_SendCommand(0x0C); // Display On, Cursor Off, Blink Off
    HAL_Delay(1);
    LCD_I2C_SendCommand(0x06); // Shift Cursor Right
    HAL_Delay(1);
    LCD_I2C_Clear(); // Clear the LCD
}

void LCD_I2C_SendCommand(uint8_t command) {
    uint8_t data[2];
    data[0] = 0x00; // Command mode
    data[1] = command;
    HAL_I2C_Master_Transmit(&hi2c2, LCD_ADDRESS, data, 2, 100);
}

void LCD_I2C_SendData(uint8_t data) {
    uint8_t lcd_data[2];
    lcd_data[0] = 0x40; // Data mode
    lcd_data[1] = data;
    HAL_I2C_Master_Transmit(&hi2c2, LCD_ADDRESS, lcd_data, 2, 100);
}

void LCD_I2C_Clear() {
    LCD_I2C_SendCommand(0x01); // Clear display
    HAL_Delay(2);
}

void LCD_I2C_SetCursor(uint8_t row, uint8_t col) {
    uint8_t position = (row == 0 ? 0x80 : 0xC0) + col;
    LCD_I2C_SendCommand(position);
}

void LCD_I2C_WriteString(char *str) {
    while (*str) {
        LCD_I2C_SendData(*str++);
    }
}
