#include"stm32f4xx.h"
void USART2_Init(void);
void USART2_Write(char data);
void delay(int sec);

int main(void){
	USART2_Init();
	for(int count=0;count<2;count++){
		USART2_Write('H');
		delay(1000);
		USART2_Write('E');
		delay(1000);
		USART2_Write('L');
		delay(1000);
		USART2_Write('L');
		delay(1000);
		USART2_Write('O');
		delay(1000);
		USART2_Write('W');
		delay(1000);
		USART2_Write('O');
		delay(1000);
		USART2_Write('R');
		delay(1000);
		USART2_Write('L');
		delay(1000);
		USART2_Write('D');
		delay(1000);
	}
	return 0;
}
void USART2_Init(void){
	RCC->APB1ENR |= 0x20000;
	RCC->AHB1ENR |= 0x1;
	GPIOA->MODER |=0x20;
	GPIOA->AFR[0] |=0x700;

	USART2->BRR |=0X683;
	USART2->CR1 |=0X8;
	USART2->CR1 |=0X2000;
}
void USART2_Write(char data){
	while(!(USART2->SR & 0X80)){}

	USART2->DR |=(data & 0xFF);
}
void delay(int sec){
	for(;sec>0;sec--){
		for(int count1=0;count1<3000;count1++){}
	}
}
